<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "conoblog");

define("ROOT_PATH", "/Tema3/ConoBlog/");
define("ROOT_URL", "http://dwesi/Tema3/ConoBlog/");
